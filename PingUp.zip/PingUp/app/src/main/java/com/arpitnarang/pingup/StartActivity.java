package com.arpitnarang.pingup;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseNetworkException;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthEmailException;
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException;
import com.google.firebase.auth.FirebaseAuthInvalidUserException;

public class StartActivity extends AppCompatActivity {

    private FirebaseAuth mAuth;

    private TextInputLayout mEmailAddress;
    private TextInputLayout mPassword;
    private Button mLogInButton;
    private Button mNeedNewAccountButton;

    private ProgressDialog mLogInProgress;
    private AlertDialog.Builder mAlertDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start);

        mAuth = FirebaseAuth.getInstance();

        mEmailAddress = (TextInputLayout)findViewById(R.id.start_email_address);
        mPassword = (TextInputLayout)findViewById(R.id.start_password);
        mLogInButton = (Button)findViewById(R.id.start_login_button);
        mNeedNewAccountButton = (Button)findViewById(R.id.start_need_new_account_button);

        mLogInProgress = new ProgressDialog(this);
        mAlertDialog = new AlertDialog.Builder(this);

        mLogInButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email_address = mEmailAddress.getEditText().getText().toString();
                String password = mPassword.getEditText().getText().toString();

                if (email_address.length() == 0) {
                    Toast.makeText(getApplicationContext(), "Please enter valid email", Toast.LENGTH_SHORT).show();
                } else if (password.length() == 0) {
                    Toast.makeText(getApplicationContext(), "Password cannot be blank", Toast.LENGTH_SHORT).show();
                } else {
                    mEmailAddress.setEnabled(false);
                    mPassword.setEnabled(false);

                    mLogInProgress.setMessage("Logging in...");
                    mLogInProgress.setCanceledOnTouchOutside(false);
                    mLogInProgress.show();

                    logInUser(email_address, password);
                }
            }
        });

        mNeedNewAccountButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent registerIntent = new Intent(StartActivity.this,RegisterActivity.class);
                startActivity(registerIntent);
            }
        });

    }

    public void logInUser(String email_address, String password){

            mAuth.signInWithEmailAndPassword(email_address,password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {
                    if(task.isSuccessful()){
                        Intent mainIntent = new Intent(StartActivity.this,MainActivity.class);
                        mainIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        mLogInProgress.dismiss();
                        startActivity(mainIntent);
                    }
                }
            }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    mEmailAddress.setEnabled(true);
                    mPassword.setEnabled(true);

                    mLogInProgress.hide();
                    mAlertDialog.setCancelable(true);
                    mAlertDialog.setTitle("Login Failed");
                    if(e instanceof FirebaseAuthEmailException){
                        mAlertDialog.setMessage("\nPlease enter valid email address.\n");
                    }
                    else if(e instanceof FirebaseAuthInvalidCredentialsException){
                        mAlertDialog.setMessage("\n"+"Invalid Password !"+"\n");
                    }
                    else if(e instanceof FirebaseNetworkException){
                        mAlertDialog.setMessage("\n"+"Please connect to the internet !"+"\n");
                    }
                    else {
                        mAlertDialog.setMessage("\n"+e.getLocalizedMessage());
                        Log.i("Failure REASON",e.getClass().toString()+"\n");
                        }
                    mAlertDialog.show();
                }
            });
    }

}