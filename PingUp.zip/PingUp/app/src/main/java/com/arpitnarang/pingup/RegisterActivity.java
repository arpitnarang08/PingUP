package com.arpitnarang.pingup;


import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Intent;

import android.support.annotation.NonNull;
import android.support.design.widget.TextInputLayout;
import android.support.v4.app.NavUtils;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseNetworkException;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthUserCollisionException;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;


public class RegisterActivity extends AppCompatActivity {

    private FirebaseAuth mAuth;
    private DatabaseReference mDatabase;

    private TextInputLayout mFullName;
    private TextInputLayout mEmailAddress;
    private TextInputLayout mPassword;
    private Button mCreateAccountButton;

    private android.support.v7.widget.Toolbar mToolbar;

    private ProgressDialog mRegProgress;
    private AlertDialog.Builder mAlertDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        mAuth = FirebaseAuth.getInstance();

        mToolbar = (android.support.v7.widget.Toolbar) findViewById(R.id.reg_toolbar);
        setSupportActionBar(mToolbar);
        getSupportActionBar().setTitle("Create Account");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        mRegProgress = new ProgressDialog(this);
        mAlertDialog = new AlertDialog.Builder(this);

        mFullName = (TextInputLayout) findViewById(R.id.reg_full_name);
        mEmailAddress = (TextInputLayout) findViewById(R.id.reg_email_address);
        mPassword = (TextInputLayout) findViewById(R.id.reg_password);

        mCreateAccountButton = (Button)findViewById(R.id.reg_create_account_button);
        mCreateAccountButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String full_name = mFullName.getEditText().getText().toString();
                String email_address = mEmailAddress.getEditText().getText().toString();
                String password = mPassword.getEditText().getText().toString();

                if(full_name.length()<2){
                    Toast.makeText(getApplicationContext(),"Please enter valid name",Toast.LENGTH_SHORT).show();
                }
                else if(email_address.length()==0){
                    Toast.makeText(getApplicationContext(),"Please enter valid email",Toast.LENGTH_SHORT).show();
                }
                else if(password.length()<8){
                    Toast.makeText(getApplicationContext(),"Password must be 8 characters long",Toast.LENGTH_SHORT).show();
                }else {
                    mRegProgress.setTitle("Please Wait");
                    mRegProgress.setMessage("Creating your account...");
                    mRegProgress.setCanceledOnTouchOutside(false);
                    mRegProgress.show();

                    createUserAccount(full_name, email_address, password);
                }
            }
        });

    }

    public void createUserAccount(String full_name, String email_address, String password){

        final String fullname = full_name;

        mAuth.createUserWithEmailAndPassword(email_address,password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if(task.isSuccessful()){

                    String uid = FirebaseAuth.getInstance().getCurrentUser().getUid();

                    mDatabase = FirebaseDatabase.getInstance().getReference().child(getString(R.string.firebase_database_name)).child(uid);

                    mRegProgress.setMessage("Setting up things for you...");

                    HashMap<String,String> newUserData = new HashMap<>();
                    newUserData.put("name",fullname);
                    newUserData.put("status",getString(R.string.default_status));
                    newUserData.put("image","default_avatar");
                    newUserData.put("thumb_image","default_thumb");

                    mDatabase.setValue(newUserData).addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if(task.isSuccessful()){
                                Intent mainIntent = new Intent(RegisterActivity.this,MainActivity.class);
                                mainIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                                mRegProgress.dismiss();
                                startActivity(mainIntent);
                            }
                        }
                    });
                }
                }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                mRegProgress.hide();

                mAlertDialog.setCancelable(true);
                mAlertDialog.setTitle("Couldn't Create Account");
                if(e instanceof FirebaseAuthUserCollisionException){
                    mAlertDialog.setMessage("\nThis email address is already registered with us.\n");
                }
                else if(e instanceof FirebaseNetworkException){
                    mAlertDialog.setMessage("\n"+"Please connect to the internet !"+"\n");
                }
                else{
                    mAlertDialog.setMessage("\n"+e.getLocalizedMessage()+"\n");
                    Log.i("Failure REASON",e.getClass().toString()+"\n");
                }
                mAlertDialog.show();
            }
        });

    }

}